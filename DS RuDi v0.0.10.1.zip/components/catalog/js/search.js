function addTag(tagname){
	
	document.searchform.tags.value += (tagname+' ');
	return;

}