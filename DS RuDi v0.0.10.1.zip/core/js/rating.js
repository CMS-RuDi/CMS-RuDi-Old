function rateItem(){	
	if (document.rateform.rating.selectedIndex>0){
		document.rateform.submit();
	}	
}