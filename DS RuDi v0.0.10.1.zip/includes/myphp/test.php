<?php

	echo '<p style="font-weight:bold">Пример инклудинга</p>';
	echo '<span>Этот текст выводится файлом "<a href="/includes/myphp/test.php">/includes/myphp/test.php</a>".</span>';

?>